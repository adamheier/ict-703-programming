print(pydoc )
