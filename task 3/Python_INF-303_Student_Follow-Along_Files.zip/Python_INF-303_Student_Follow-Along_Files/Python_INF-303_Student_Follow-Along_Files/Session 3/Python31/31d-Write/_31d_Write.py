writeFile = 
toLog = 

writeFile.close()

